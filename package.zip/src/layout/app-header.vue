<script setup lang="ts"></script>
<template>
  <div
    class="app-header fixed top-0 left-0 w-full h-headerH backdrop-blur-sm bg-white/30 leading-10 tracking-wide text-xl"
  >
    你要明白， 你是独一无二的， 在你的主场， 你就是主角。
  </div>
</template>

<style lang="scss" scoped>

</style>
