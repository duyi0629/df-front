<script setup lang='ts'>

</script>
<template>
  <div class="fixed left-16">
app-menu
  </div>
</template>

<style lang='scss' scoped>

</style>